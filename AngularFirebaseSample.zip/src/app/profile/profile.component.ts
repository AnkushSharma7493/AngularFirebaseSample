import { Component, OnInit } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { Customer } from '../model/Customer';
import { FileMetaData } from '../model/FileMetaData';
import { FileService } from '../services/file.service';
import { catchError, finalize } from 'rxjs/operators';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private fileSvc : FileService, private fileStorage : AngularFireStorage) { }

  ngOnInit(): void {
    this.fileSvc.setCollectionName("Profile");
    this.getAllFiles();
  }

  selectedFiles !: FileList;
  currentFileUpload !:FileMetaData;
  customer !: Customer;
  file !: FileMetaData;
  percentage : number = 0;
  
  listOfFiles : FileMetaData[]=[];

  selectFile(event:any)
  {
    this.selectedFiles=event.target.files;
  }

  uploadFile()
  {
    this.currentFileUpload=new FileMetaData(this.selectedFiles[0]);
    const path = "uploads/"+this.currentFileUpload.file.name;

    const storageRef = this.fileStorage.ref(path);
    const uploadTask=storageRef.put(this.selectedFiles[0]);

    uploadTask.snapshotChanges().pipe(finalize(
      ()=>{
        storageRef.getDownloadURL().subscribe(downloadLink=>{
          this.currentFileUpload.url=downloadLink;
          this.currentFileUpload.size=this.currentFileUpload.file.size;
          this.currentFileUpload.name=this.currentFileUpload.file.name;

          this.fileSvc.saveFileMetadata(this.currentFileUpload);
        })
      }
    ))
    .subscribe(
      (res:any)=>{
        this.percentage = (res.bytesTransferred*100/res.totalBytes);
      },
      err=>{
        alert("Something went worng "+err.messgae);
      }
    );
  }


  getAllFiles()
  {
    this.fileSvc.getAllFiles().subscribe(
      res=>{
        this.listOfFiles=res.map((e:any)=>{
          const data = e.payload.doc.data();
          data.id=e.payload.doc.id;
          return data;
        })
      },
      err=>{
        alert("Something went wrong "+err.message);
      }
    )
  }

  deleteFile(file : FileMetaData)
  {
     this.fileSvc.deleteFile(file);
     this.ngOnInit();
  }

  check()
  {
    alert(this.listOfFiles.length);
  }

}
