import { Component, OnInit } from '@angular/core';
import { Booking } from '../model/Booking';
import { AppContextService } from '../services/app-context.service';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  constructor(private dataSvc : DataService,
    public appContext : AppContextService) { 
      this.dataSvc.setCollectionName('Booking');
    }

  bookings : Booking[]=[];


  ngOnInit(): void {
    this.appContext.getUserToken();

    if(this.appContext.islogin)
    {
      this.getBookings();
    }
    
  }


  public getBookings()
  {
    this.dataSvc.getSnapshotModelByCustomer(this.appContext.token).subscribe(
      res => {
        this.bookings=res.map((e:any)=>{
          this.trigger();
          const booking = e.payload.doc.data();
          booking.id=e.payload.doc.id;
          console.log("->  "+booking.id);
          return booking;
        })
      },
      err => {
        alert("Something went wrong "+err.message);
      }
    );
  }

  public trigger()
  {
    console.log("Booking data changed "+new Date());
  }

}
