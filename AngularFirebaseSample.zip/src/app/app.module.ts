import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { AppContextService } from './services/app-context.service';
import { PlansComponent } from './plans/plans.component';
import { RefferalComponent } from './refferal/refferal.component';
import { SignupComponent } from './signup/signup.component';
import { ProfileComponent } from './profile/profile.component';
import { BookingComponent } from './booking/booking.component';
import { WalletComponent } from './wallet/wallet.component';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './footer/footer.component';
import { SigninComponent } from './signin/signin.component';
import { AngularFireAnalyticsModule } from '@angular/fire/compat/analytics';
import { AngularFireModule } from '@angular/fire/compat';
import { environment } from '../environments/environment';
import { FormsModule } from '@angular/forms';
import { AppUtilsService } from './services/app-utils.service';
import { AuthService } from './services/auth.service';
import { DataService } from './services/data.service';
import { FileService } from './services/file.service';
import { ToastComponent } from './ui/toast/toast.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    PlansComponent,
    RefferalComponent,
    SignupComponent,
    ProfileComponent,
    BookingComponent,
    WalletComponent,
    HomeComponent,
    FooterComponent,
    SigninComponent,
    ToastComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFireModule.initializeApp(environment.firebase),
    AngularFireAnalyticsModule,
    FormsModule
  ],
  providers: [
    AppContextService,
    AppUtilsService,
    AuthService,
    DataService,
    FileService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }



