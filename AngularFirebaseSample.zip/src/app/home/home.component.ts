import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Booking } from '../model/Booking';
import { AppContextService } from '../services/app-context.service';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private dataSvc : DataService, private router : Router,private appContext : AppContextService) { 
      this.dataSvc.setCollectionName("Booking");
  }

  booking : Booking = new Booking(this.appContext.token);
  

  ngOnInit(): void {
    this.appContext.getUserToken();
  }

  createBooking()
  {
    this.dataSvc.addModel(this.booking).then(
      res=>{
        this.booking=new Booking(this.appContext.token);
        alert("Booking created successfully");
        this.router.navigate(["/booking"]);
      },
      err=>{
        alert("Please try again");
      }

    );
  }

}
