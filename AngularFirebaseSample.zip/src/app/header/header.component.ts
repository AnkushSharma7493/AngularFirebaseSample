import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppUtilsService } from '../services/app-utils.service';
import { AppContextService } from '../services/app-context.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  selectedCity:any='Your Location';
  constructor(public appContext : AppContextService,
              public util : AppUtilsService,
              public router : Router) { 
  }

  ngOnInit(): void {
    // get location
    this.selectedCity=this.appContext.getLocation();
  }

  isHover:number=0;
  
  selectCity(index:number)
  {
    this.selectedCity=this.appContext.cities[index];
    this.appContext.setLocation(this.selectedCity);
    this.util.closePopup('LOC');
  }
}
