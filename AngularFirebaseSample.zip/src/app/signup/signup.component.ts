import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private authService : AuthService) { }
  
  email:string="";
  phone:string="";
  password:string="";
  refferalCode:string="";
  
  ngOnInit(): void {
  }

  register() {
    this.authService.register(this.email,this.password);
  }

}
