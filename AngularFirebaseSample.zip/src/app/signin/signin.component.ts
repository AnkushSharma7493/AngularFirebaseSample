import { Component, OnInit } from '@angular/core';
import { AppContextService } from '../services/app-context.service';
import { AppUtilsService } from '../services/app-utils.service';
import { AuthService } from '../services/auth.service';


@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  constructor(private authService : AuthService,
              public appContext : AppContextService,
              public util : AppUtilsService) { }
  
  email:string="";
  phone:string="";
  password:string="";
  displayStyle:string="none";

  ngOnInit(): void {
    this.appContext.getUserToken();
  }

  login() {
    this.authService.login(this.email,this.password);
  }
  
  forgotPassword()
  {
    this.authService.forgotPassword(this.email);
    this.email="";
  }

  loginWithGoogle()
  {
    this.authService.loginWithGoogle();
  }

}
