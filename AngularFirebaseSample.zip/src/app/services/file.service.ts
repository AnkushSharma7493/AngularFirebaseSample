import { Injectable } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { FileMetaData } from '../model/FileMetaData';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})
export class FileService {

  constructor(private fireStore : AngularFirestore,
              private fireStorage : AngularFireStorage,
              private dataSvc : DataService) { 

  }

  collectionName : string ="";

  setCollectionName(collectionName : string) : FileService
  {
    this.collectionName=collectionName;
    this.dataSvc.setCollectionName(this.collectionName);
    return this;
  }

  // save Metadata
  saveFileMetadata(fileMD : FileMetaData)
  {
    this.dataSvc.addModel(fileMD);
  }

// Get All Files
getAllFiles()
{
  return this.dataSvc.getAllModels();
}

deleteFile(file:FileMetaData)
{
  this.dataSvc.deleteModel(file);
  this.fireStorage.ref("/uploads/"+file.name).delete();
}

}
