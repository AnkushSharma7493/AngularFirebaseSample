import { Injectable } from '@angular/core';
import {AngularFireAuth} from '@angular/fire/compat/auth'
import {GoogleAuthProvider, FacebookAuthProvider, GithubAuthProvider, TwitterAuthProvider} from '@angular/fire/auth'
import { Router } from '@angular/router';
import { AppUtilsService } from './app-utils.service';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private fireAuth : AngularFireAuth,
              private router : Router,
              private util : AppUtilsService) { }

  // login method
  login(email : string, password : string)
  {
    this.fireAuth.signInWithEmailAndPassword(email,password).then(
      res=>{
        localStorage.setItem("token",JSON.stringify(res.user?.uid));
        if(res.user?.emailVerified == true){
          this.router.navigate(["/home"]);
        }
        else{
          this.util.openPopup('VE'); 
        }

      },
      err=>{
        alert("Something went wrong "+err.message);
        this.router.navigate(["/signin"]);
      }
    );
  }

  // Google Login
  loginWithGoogle()
  {
    return this.fireAuth.signInWithPopup(new GoogleAuthProvider).then(
      res=>{
        var token=JSON.stringify(res.user?.uid);
        localStorage.setItem("token",token.substr(1,token.length-2));
        this.router.navigate(["/home"]);
      },
      err=>{
        alert("Something went worng "+err.message);
      }
    );
  }


  //register method
  register(email : string, password : string)
  {
    this.fireAuth.createUserWithEmailAndPassword(email,password).then(
      res=>{
        alert("Registeration Successful");
        this.router.navigate(["/signin"]);
        this.SendEmailForVerification(res.user);
      },
      err=>{
        alert("Something went wrong "+err.message);
        this.router.navigate(["/signup"]);
      }
    );
  }

// signout
logout()
{
  this.fireAuth.signOut().then(
    ()=>{
      localStorage.removeItem("token");
      this.router.navigate(["/signin"]);
    },
    err=>{
      alert(err.message);
    }
  );
}

forgotPassword(email:string)
{
  this.fireAuth.sendPasswordResetEmail(email).then(
    ()=>{
      this.util.closePopup('FP');
      this.util.openPopup('VE');
    },
    err=>{
      alert("Something went woring "+err.message);
    }
  );
}

SendEmailForVerification(user:any)
{
  user.SendEmailForVarification().then(
    (res:any)=>{
      this.util.openPopup('VE');
    },
    (err:any)=>{
      alert("Something went wrong. Not able to send email to your emailID.");
    }
  );
}


}
