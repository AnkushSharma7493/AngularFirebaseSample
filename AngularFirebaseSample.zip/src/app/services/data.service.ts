import { Injectable } from '@angular/core';
import { AngularFirestore, DocumentReference, Query } from '@angular/fire/compat/firestore';
import { AppModel } from '../model/AppModel';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private afs : AngularFirestore) { }

  collectionName : string="";

  setCollectionName(name:string){
    this.collectionName=name;
  }

  addModel(model : AppModel) : Promise<DocumentReference<unknown>>
  {
    model.id=this.afs.createId();
   return this.afs.collection("/"+this.collectionName).add(model.toString());
  }
  
  updateModel(model : AppModel)
  {
    return this.afs.doc("/"+this.collectionName+"/").update(model.id);
  }

  deleteModel(model : AppModel)
  {
    return this.afs.doc("/"+this.collectionName+"/"+model.id).delete();
  }

  getModel(model : AppModel)
  {
    return this.afs.doc("/"+this.collectionName+"/"+model.id).get();
  }  

  // snapshot changes refereshes the data automatically.
  getAllModels()
  {
    return this.afs.collection("/"+this.collectionName+"").snapshotChanges();
  }

  getSnapshotModelByCustomer(id:string)
  {
    return this.afs.collection("/"+this.collectionName+"",ref => ref.where('custumerId', '==', id)).snapshotChanges();
  }


}
