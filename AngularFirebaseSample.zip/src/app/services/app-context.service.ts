import { Injectable } from '@angular/core';
import { Customer } from '../model/Customer';
import { environment } from '../../environments/environment'
import { AuthService } from './auth.service';



@Injectable({
  providedIn: 'root'
})
export class AppContextService {

  constructor(private authService : AuthService) { }

  public businessEmail=environment.config.email;
  public businessphone=environment.config.phone;
  public cities : string[]=environment.config.cities.split(",");
  public user !: Customer;
  public token : any;
  public islogin : boolean=false;

  public setUserDetails(userDetails:Customer)
  {
    this.user=userDetails;
  }

  public getUserToken()
  {
    this.token=localStorage.getItem('token');
     if(this.token==null){
        this.islogin=false;
     }else{
      this.islogin=true;
     }
  }
  
  public logout() {
    this.authService.logout();
  }

  public getLocation()
  {
    return localStorage.getItem('location');
  }

  public setLocation(location:string)
  {
    localStorage.setItem('location',location);
  }
  
  
}
