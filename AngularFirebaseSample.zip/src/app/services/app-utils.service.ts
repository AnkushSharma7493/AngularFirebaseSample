import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppUtilsService {

  constructor() { }

  isHover:number=0;
  displayStyle_ve = "none";
  displayStyle_fp = "none";
  displayStyle_loc = "none";

  openPopup(popup:string) {
    switch(popup)
    {
      case "FP"   : this.displayStyle_fp="block";break;
      case "VE"   : this.displayStyle_ve="block";break;
      case "LOC"  : this.displayStyle_loc="block";break;
    }
  }
  closePopup(popup:string) {
    switch(popup)
    {
      case "FP"   : this.displayStyle_fp="none";break;
      case "VE"   : this.displayStyle_ve="none";break;
      case "LOC"  : this.displayStyle_loc="none";break;
    }
  }

}
