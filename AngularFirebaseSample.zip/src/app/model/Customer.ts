import { AppModel } from "./AppModel";

export class Customer extends AppModel {

    fName:string="";
    lName:string="";
    email:string="";
    phone:string="";
    profilePic:string="";
    walletAmount:number=0;
}