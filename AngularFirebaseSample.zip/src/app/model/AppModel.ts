export class AppModel
{
    id : string ="";


    toString()
    {
        return JSON.parse(JSON.stringify(this));
    }
}
