import { AppModel } from "./AppModel";

export class FileMetaData extends AppModel {

    name : string="";
    size : number=0;
    url : string="";
    file : File;

    constructor(file:File)
    {
        super();
        this.file=file;
    }
}