import { Time } from "@angular/common";
import { AppModel } from "./AppModel";

export class Booking  extends AppModel{

    custumerId : string ="";
    
    customerName : string="";
    customerPhone : string="";
    customerEmail : string="";
    rideDate : Date = new Date();
    rideTime : string = "";
    sourceAddress : string ="";
    destinationAddress : string ="";
  
   
    driverId : string ="";
    driverPhone : string ="";
  
    customerNote : string ="";
    status : string = "";
    feedback : string ="";
    rating : number=0;
    rideCompletedDateTime : Date = new Date("0000-00-00T00:00:00.000Z");
    bookingDateTime : Date = new Date();


    constructor(cid:string){        
        super();
        // initialize something;
        if(cid==undefined){
            this.custumerId='123';
        }
        else{
            this.custumerId=cid;
        }
        
    }

}