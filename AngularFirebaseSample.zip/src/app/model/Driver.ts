import { AppModel } from "./AppModel";

export class Driver  extends AppModel{

    fName:string="";
    lName:string="";
    email:string="";
    phone:string="";
    profilePic:string="";
    walletAmount:number=0;
}
