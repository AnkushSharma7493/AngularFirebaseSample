import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-refferal',
  templateUrl: './refferal.component.html',
  styleUrls: ['./refferal.component.css']
})
export class RefferalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
