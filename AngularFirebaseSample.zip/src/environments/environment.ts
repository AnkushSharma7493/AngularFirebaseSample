// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'sharmadriverservice',
    appId: '1:579808199622:web:29844621cd11cb5852e8c7',
    databaseURL: 'https://sharmadriverservice-default-rtdb.asia-southeast1.firebasedatabase.app',
    storageBucket: 'sharmadriverservice.appspot.com',
    apiKey: 'AIzaSyDoBWa_-d8IVLAQ9gLrcBHuYzdAEN3oci4',
    authDomain: 'sharmadriverservice.firebaseapp.com',
    messagingSenderId: '579808199622',
    measurementId: 'G-RJPG2YPP2P'
  },
  production: false,
  config:{
    cities : "Ghaziabad,Noida,Delhi",
    email : "sharmadriverservice@gmail.com",
    phone : "+012 345 6789"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
