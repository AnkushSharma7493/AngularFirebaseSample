export const environment = {
  firebase: {
    projectId: 'sharmadriverservice',
    appId: '1:579808199622:web:29844621cd11cb5852e8c7',
    databaseURL: 'https://sharmadriverservice-default-rtdb.asia-southeast1.firebasedatabase.app',
    storageBucket: 'sharmadriverservice.appspot.com',
    apiKey: 'AIzaSyDoBWa_-d8IVLAQ9gLrcBHuYzdAEN3oci4',
    authDomain: 'sharmadriverservice.firebaseapp.com',
    messagingSenderId: '579808199622',
    measurementId: 'G-RJPG2YPP2P',
  },
  production: true
};
